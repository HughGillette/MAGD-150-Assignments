function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(40);

push();
strokeWeight(10);
stroke(0, 0, 255);
point(30, 50);
pop();
  

  
  
push();
fill(255, 255, 0);
triangle(160, 300, 200, 220, 240, 300);
pop();

push();
fill('#7FB3D5');
arc(200, 200, 80, 80, PI, TWO_PI, OPEN);
pop();
  
push();
strokeWeight(8);
stroke(0, 170, 0);
point(210, 195);
pop();
  

push();
strokeWeight(8);
stroke(0, 170, 0);
point(190, 195);
pop();



push();
colorMode(HSB);
fill(20, 255, 80);
quad(162, 200, 110, 240, 290, 240, 238, 200);
pop();

  
  
  
}